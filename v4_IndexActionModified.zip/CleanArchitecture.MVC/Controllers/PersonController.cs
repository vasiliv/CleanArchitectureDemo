﻿using CleanArchitecture.Application.Interfaces;
using CleanArchitecture.Application.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CleanArchitecture.MVC.Controllers
{
    public class PersonController : Controller
    {
        private IPersonService _personService;
        public PersonController(IPersonService personService)
        {
            _personService = personService;
        }
        public IActionResult Index()
        {
            PersonViewModel model = _personService.GetPersons();
            return View(model);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(PersonViewModel personViewModel)
        {
            _personService.Add(personViewModel);            
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(Guid? id)
        {
            PersonViewModel model = _personService.GetPersonById(id);
            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(PersonViewModel personViewModel)
        {
            if (ModelState.IsValid) { 
            _personService.Update(personViewModel);            
            }
            return RedirectToAction(nameof(Index));
        }
        public IActionResult Delete(Guid? id)
        {
            PersonViewModel model = _personService.GetPersonById(id);
            return View(model);
        }
        [HttpPost]
        public IActionResult Delete(PersonViewModel personViewModel)
        {
            if (ModelState.IsValid)
            {
                _personService.Remove(personViewModel);
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
