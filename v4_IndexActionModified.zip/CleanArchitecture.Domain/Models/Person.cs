﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Models
{
    public class Person
    {
        public Guid Id { get; set; }
        public string FirstNameGeorgian { get; set; }
        public string FirstNameLatin { get; set; }
        public string SecondNameGeorgian { get; set; }
        public string SecondNameLatin { get; set; }
        public int IdentityNumber { get; set; }
        public DateTime BornDate { get; set; }
        public string Address { get; set; }
        public List<ContactInformation> ContactInformation { get; set; }
        //Todo Photo
        //Todo Relations
    }
}
